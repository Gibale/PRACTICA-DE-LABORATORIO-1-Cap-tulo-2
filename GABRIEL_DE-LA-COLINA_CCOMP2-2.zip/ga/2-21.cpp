#include <iostream>
using namespace std;

int main(){

    cout << "   CCC   +      +\n";
    cout << " C       +      + \n";
    cout << "C      +++++  +++++ \n";
    cout << " C       +      + \n";
    cout << "  CCC    +      +" << endl;

    return 0;
}