#include <iostream>
using namespace std;

int main(){

    cout << "Con la mayor cantidad de lineas \"8\"" << endl;

    cout << "* * * * * * * *" << endl;
    cout << " * * * * * * * *" << endl;
    cout << "* * * * * * * *" << endl;
    cout << " * * * * * * * *" << endl;
    cout << "* * * * * * * *" << endl;
    cout << " * * * * * * * *" << endl;

    cout << "Con la menor cantidad de lineas: " << endl;

   cout << "* * * * * * * * \n * * * * * * * * \n* * * * * * * * \n * * * * * * * *\n";
   cout << "* * * * * * * * \n * * * * * * * * \n* * * * * * * * \n * * * * * * * *\n";

    return 0;
}