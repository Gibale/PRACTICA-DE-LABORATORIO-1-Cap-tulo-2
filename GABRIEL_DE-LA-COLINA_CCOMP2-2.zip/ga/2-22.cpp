#include <iostream>
using namespace std;

int main(){

    cout << "*****\n****\n***\n**\n*\n" << endl;

    return 0;
}